package test;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class day1 {

	@AfterTest
	public void lastOne() {
		System.out.println("This will execute Last");
	}
	
	@AfterMethod
	public void bfmethod() {
		System.out.println("I will Execute after every method of day1 class");
	}
	
	@Test
	public void test() {
		
		System.out.println("Hello");
	}
	
	@AfterSuite
	public void afSuite() {
		System.out.println("Iam always Last");
	}
	
	@Test
	public void demo( ) {
		System.out.println("Hii");
	}
	
}
