package test;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class day4 {

	
	@Test(timeOut=4000)
	public void WebLoginHomeLoan() {

		System.out.println("WebLoginHome");
		Assert.assertTrue(false);
	}

	@Parameters({"URL"})
	@Test
	public void MobileLoginHomeLoan(String urlname) {

		System.out.println("MobileLoginHome");
		System.out.println(urlname);
	}

	@Test(groups= {"smoke"})
	public void APILoginHomeLoan() {

		System.out.println("APILoginHome");
	}

	
}
