package test;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class day2 {

	@Test(groups= {"smoke"})
	public void run() {
		System.out.println("Welcome");
	}
	
	@BeforeTest
	public void brfore() {
		System.out.println("This will execute first");
	}
}
