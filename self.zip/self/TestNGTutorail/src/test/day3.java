package test;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class day3 {

	
	@Test(groups= {"smoke"})
	public void WebLoginCarLoan() {

		System.out.println("WebLoginCar");
	}

	@BeforeMethod
	public void bfmethod() {
		System.out.println("I will Execute before every method of day3 class");
	}
	
	@Parameters({"URL","APIkey/usrname"})
	@Test
	public void MobileLoginCarLoan(String Urlname,String key) {

		System.out.println("MobileLoginCar");
		System.out.println(Urlname);
		System.out.println(key);
	}
	
	
	@Test(dataProvider = "getData")
	public void MobileSigninCarLoan(String usrname, String pword) {

		System.out.println("Mobile SignIn");
		System.out.println(usrname);
		System.out.println(pword);
	}
	
	@BeforeSuite
	public void bfSuite() {
		System.out.println("Iam the first One");
	}
	
	@Test(enabled=false)
	public void MobileSignoutCarLoan() {

		System.out.println("Mobile SignOut");
	}

	@Test(dependsOnMethods= {"WebLoginCarLoan"})
	public void APILoginCarLoan() {

		System.out.println("APILoginCar");
	}
	
	@DataProvider
	public Object[][] getData() {
		
		Object[][] data = new Object[3][2];
		//1st set
		data[0][0] = "firstusername";
		data[0][1] = "password";
		
		//2nd set
		data[1][0] = "secondusername";
		data[1][1] = "secondpassword";
		
		//3rd set
		data[2][0] = "thirdusername";
		data[2][1] = "thirdpassword";
		
		return data;
		
	}

}
