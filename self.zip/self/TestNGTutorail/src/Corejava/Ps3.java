package Corejava;

public class Ps3 {

	int a;

	public Ps3(int a) {
		
		this.a = a;
	}

	public int multiplyTwo() {
		a = a * 2;
		return a;
	}

	public int multiplyThree() {
		a = a * 3;
		return a;
	}

}
