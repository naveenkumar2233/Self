package Corejava;

import org.testng.annotations.Test;

public class Ps1 extends Ps {

	@Test
	public void reg()
	{
		Ps2 ps2 = new Ps2(3);
		demo();
		System.out.println(ps2.increment());
		System.out.println(ps2.decrement());
		System.out.println(ps2.multiplyThree());
		
		
	}
	
	
}
