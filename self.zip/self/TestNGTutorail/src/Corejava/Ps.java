package Corejava;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class Ps {

	
	@BeforeTest
	public void befTest()
	{
		System.out.println("Run me first");
	}
	
	@AfterTest
	public void afTest() {
		System.out.println("Run me Last");
	}
	
	public void demo() {
		
		System.out.println("I am here");
	}
}
