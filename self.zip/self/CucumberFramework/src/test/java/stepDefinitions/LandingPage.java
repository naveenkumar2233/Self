package stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.LandingsPage;
import utils.TextContextSetup;

public class LandingPage {

public WebDriver driver;	
public String offerPageProductName;
public String landingPageProductName;
TextContextSetup textContextSetup;

public LandingPage(TextContextSetup textContextSetup) {
	this.textContextSetup = textContextSetup;
}

	@Given("User is on GreenCart Landing page")
	public void user_is_on_green_cart_landing_page() {
	    
//		//System.setProperty("webdriver.chrome.driver", "C:/Users/navebodd/Documents/chromedriver.exe");
//		textContextSetup.driver = new ChromeDriver();
//		textContextSetup.driver.get("https://rahulshettyacademy.com/seleniumPractise/");
	}
	@When("^user searched with Shortname (.+) and extracted actual name of product$")
	public void user_searched_with_shortname_and_extracted_actual_name_of_product(String shortName) throws InterruptedException {
		LandingsPage landingsPage = textContextSetup.pageObjectManager.getLandingPage();
		landingsPage.searchItem(shortName);
		Thread.sleep(2000);
		
		textContextSetup.landingPageProductName = landingsPage.getProduct().split("-")[0].trim();
		System.out.println(textContextSetup.landingPageProductName);
		
	}
	
	
}
