package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckoutPage {
	
	public WebDriver driver;
	
	public CheckoutPage(WebDriver driver) {
		this.driver = driver;
	}
	
	private By productName = By.cssSelector(".product-name");
	private By additem = By.cssSelector(".increment");
	private By addProduct = By.cssSelector("div.product-action button");
	private By cartIcon = By.cssSelector(".cart-icon");
	private By Checkout = By.cssSelector(".action-block button");
	private By promoCode = By.cssSelector(".promoBtn");
	private By placeOrder = By.xpath("//button[contains(text(),'Place Order')]");
	
	public String getProductName() {
		return driver.findElement(productName).getText();
	}
	public void itemQuantity(int num) {
		for(int i=0;i<num;i++) {
			driver.findElement(additem).click();
		}
	}
	
	public void addItemToCart() {
		driver.findElement(addProduct).click();
	}
	public void checkoutpages() {
		driver.findElement(cartIcon).click();
		driver.findElement(Checkout).click();
	}
	public boolean verifyPromo() {
		return driver.findElement(promoCode).isDisplayed();
	}
	public boolean verifyPlaceOrder() {
		return driver.findElement(placeOrder).isDisplayed();
	}

}
