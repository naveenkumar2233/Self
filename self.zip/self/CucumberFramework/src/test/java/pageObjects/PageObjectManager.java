
package pageObjects;

import org.openqa.selenium.WebDriver;

public class PageObjectManager {

public WebDriver driver;
public LandingsPage landingsPage;
public OffersPage offersPage;
public CheckoutPage checkoutPage;
	
	public PageObjectManager(WebDriver driver) {
		this.driver = driver;
	}
	
	public LandingsPage getLandingPage() {
		return landingsPage = new LandingsPage(driver);
	}
	
	public OffersPage getOfferPage() {
		return offersPage = new OffersPage(driver);

	}
	public CheckoutPage checkoutPage() {
		return checkoutPage = new CheckoutPage(driver);
	}
	
}
