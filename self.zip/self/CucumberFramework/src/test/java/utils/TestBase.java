package utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class TestBase {
	
public WebDriver driver;
	
	public TestBase(WebDriver driver) {
		this.driver = driver;
	}
	
	public WebDriver webDriverManager() throws IOException {
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+ "//src//test//resources//global.properties");
		Properties prop = new Properties();
		prop.load(fis);
		String Url = prop.getProperty("QaUrl");
		String browser_maven = System.getProperty("browser");
		String browser_properties = prop.getProperty("browser");
		
		String browser = browser_maven!=null ? browser_maven : browser_properties;
		
		if(driver == null) {
		//System.setProperty("webdriver.chrome.driver", "C:/Users/navebodd/Documents/chromedriver.exe");
			if(browser.equalsIgnoreCase("chrome")) {
				driver = new ChromeDriver();
			}
			if(browser.equalsIgnoreCase("edge")) {
				driver = new EdgeDriver();
			}
			//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			driver.get(Url);
		
		}
		return driver;
	}

}
