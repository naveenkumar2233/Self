package stepDefinitions;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class hooks {

	@Before("@netbanking")
	public void netBankingSetup() {
		System.out.println("**************");
		System.out.println("Setup the entries in Netbanking database");
	}
	
	@After
	public void tearDown() {
		System.out.println("clear the entries");
	}
	
	@Before("@Mortgage")
	public void mortgageSetup() {
		System.out.println("Setup the entries in mortgage database");
	}
	//before>>background>>scenario>>after
	
	
}
