package stepDefinitions;

import java.util.List;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MainSteps {

	@Given("User is on Netbanking Login Page")
	public void user_is_on_netbanking_login_page() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("User Landed on Login page");
	}
	
	@Given("User is on practice signup page")
	public void user_is_on_practice_signup_page() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("User Landed on practise signin page");
		}
	
	@When("User login to application")
	public void user_login_to_application(List<String> data) {
	    System.out.println(data.get(0));
	    System.out.println(data.get(1));
	    System.out.println(data.get(2));
	    System.out.println(data.get(3));
	}
	
	
//	@When("User Login to Application with {string} and password {string}")
//	public void user_login_to_application(String user, String password) {
//	    // Write code here that turns the phrase above into concrete actions
//	    System.out.println("User Login into Application with " +user+ " and password " +password);
//	}
	
	@When("^User Login to Application with (.+) and password (.+)$")
	public void user_login_to_application(String user, String password) {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("User Login into Application with " +user+ " and password " +password);
	}
	
	@When("Home Page is displayed")
	public void home_page_is_displayed() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Home Page is displayed");
	}
	@Then("Cards are displayed")
	public void cards_are_displayed() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Cards are displayed");
	}
	
	 
	@Given("setup the entries in database")
	public void setupentries_database() {
		System.out.println("************");
		System.out.println("setup the entries in database");
	}
	
	@When("launch the browser from congfig variables")
	public void launch_browser() {
		System.out.println("lauch the browser from congfig variables");
	}
	
	@When("Hit the home page url of banking site")
	public void hit_homepage() {
		System.out.println("Hit the home page url of banking site");
	}

	
}
