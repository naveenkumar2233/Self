package heroku;

import java.io.File;
import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ContextMenu {
	WebDriver driver;

	@BeforeTest
	public void beforeEach() {
		driver = new ChromeDriver();
	}

	@AfterTest
	public void tearDown() throws InterruptedException {
		Thread.sleep(Duration.ofSeconds(5).toMillis());
		driver.quit();
	}

	// @Test
	public void context() throws InterruptedException {
		driver.get("https://the-internet.herokuapp.com/");
		driver.findElement(By.linkText("Context Menu")).click();
		Actions a = new Actions(driver);
		WebElement click = driver.findElement(By.id("hot-spot"));
		a.moveToElement(click).contextClick().build().perform();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();

	}

	// @Test
	public void dragDrop() {
		driver.get("https://the-internet.herokuapp.com/");
		driver.findElement(By.linkText("Drag and Drop")).click();
		Actions a = new Actions(driver);
		WebElement source = driver.findElement(By.id("column-a"));
		WebElement target = driver.findElement(By.id("column-b"));
		a.dragAndDrop(source, target).build().perform();
	}

	// @Test
	public void dropDown() {
		driver.get("https://the-internet.herokuapp.com/");
		driver.findElement(By.linkText("Dropdown")).click();
		driver.findElement(By.id("dropdown")).click();
		List<WebElement> options = driver.findElements(By.tagName("option"));
		for (WebElement option : options) {
			if (option.getText().equalsIgnoreCase("option 2")) {
				option.click();
				break;
			}

		}
	}

	// @Test
	public void dynamicControl() throws InterruptedException {
		driver.get("https://the-internet.herokuapp.com/");
		driver.findElement(By.linkText("Dynamic Controls")).click();
		boolean click = driver.findElement(By.xpath("//input[@type='checkbox']")).isDisplayed();
		if (click) {
			driver.findElement(By.cssSelector("form[id='checkbox-example'] button")).click();
		}
		Thread.sleep(5000);
		driver.findElement(By.cssSelector("form[id='checkbox-example'] button")).click();
		Thread.sleep(5000);

		boolean text = driver.findElement(By.cssSelector("input[type='text']")).isEnabled();
		if (!text) {
			driver.findElement(By.cssSelector("form[id='input-example'] button")).click();
		}

	}

	// @Test
	public void dynamicLoading() throws InterruptedException {
		driver.get("https://the-internet.herokuapp.com/");
		driver.findElement(By.linkText("Dynamic Loading")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Example 1: Element on page that is hidden')]")).click();
		driver.findElement(By.cssSelector("button")).click();
		Thread.sleep(5000);
		String msg = driver.findElement(By.id("finish")).getText();
		Assert.assertEquals("Hello World!", msg);
		driver.navigate().back();
		driver.findElement(By.linkText("Example 2: Element rendered after the fact")).click();
		driver.findElement(By.cssSelector("button")).click();
		Thread.sleep(5000);
		String msg1 = driver.findElement(By.id("finish")).getText();
		Assert.assertEquals("Hello World!", msg1);

	}

	// @Test
	public void entryAd() throws InterruptedException {
		driver.get("https://the-internet.herokuapp.com/");
		driver.findElement(By.linkText("Entry Ad")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".modal-footer")).click();

	}

	// @Test
	public void exitIntent() throws InterruptedException {
		driver.manage().window().maximize();
		driver.get("http://the-internet.herokuapp.com/exit_intent");
//			 Thread.sleep(3000);
//		        Robot robot = new Robot();
//		        robot.mouseMove(600,0);
//		        Thread.sleep(3000);
//		        driver.findElement(By.xpath(".//*[@id='ouibounce-modal']/div[2]/div[3]/p")).click();

		WebElement e = driver.findElement(By.cssSelector("h3"));
		Actions action = new Actions(driver);
		action.moveToElement(e).moveByOffset(600, -1).build().perform();
		Thread.sleep(2000);
		driver.findElement(By.xpath(".//*[@id='ouibounce-modal']/div[2]/div[3]/p")).click();

	}

	// @Test
	public void download() throws InterruptedException {
		driver.manage().window().maximize();
		driver.get("http://the-internet.herokuapp.com/download");
		driver.findElement(By.linkText("test-file.txt")).click();
	}

	// @Test
	public void upload() throws InterruptedException {
		String fileName = "test-file.txt";
		File file = new File(fileName);
		String path = file.getAbsolutePath();
		driver.manage().window().maximize();
		driver.get("http://the-internet.herokuapp.com/upload");
		driver.findElement(By.cssSelector("#file-upload")).sendKeys(path);
		driver.findElement(By.id("file-submit")).click();
		String text = driver.findElement(By.id("uploaded-files")).getText();
		Assert.assertEquals(fileName, text);
	}

	// @Test
	public void form() throws InterruptedException {
		driver.manage().window().maximize();
		driver.get("http://the-internet.herokuapp.com/login");
		driver.findElement(By.id("username")).sendKeys("tomsmith");
		driver.findElement(By.id("password")).sendKeys("SuperSecretPassword!");
		driver.findElement(By.cssSelector(".radius")).click();
		Thread.sleep(2000);
		String msg = driver.findElement(By.id("flash")).getText();
		System.out.println(msg);
		driver.findElement(By.cssSelector(".button.secondary.radius")).click();
		driver.findElement(By.id("username")).sendKeys("tomsmith");
		driver.findElement(By.id("password")).sendKeys("SuperSecret");
		driver.findElement(By.cssSelector(".radius")).click();
		Thread.sleep(2000);
		String msgerror = driver.findElement(By.id("flash")).getText();
		System.out.println(msgerror);
	}

	// @Test
	public void horizontalSlider() throws InterruptedException {
			driver.manage().window().maximize();
			driver.get("http://the-internet.herokuapp.com/horizontal_slider");
			WebElement slide = driver.findElement(By.xpath("//input[@type='range']"));
			Actions a = new Actions(driver);
			for(int i=0;i<5;i++)
			slide.sendKeys(Keys.ARROW_RIGHT);
			a.moveToElement(slide).clickAndHold().sendKeys(Keys.ARROW_LEFT).release().perform();
			String text = driver.findElement(By.id("range")).getText();
			Assert.assertEquals("2.5", text);
		}

	//@Test
	public void hovers() throws InterruptedException {
		driver.manage().window().maximize();
		driver.get("http://the-internet.herokuapp.com/hovers");
		List<WebElement> fig = driver.findElements(By.xpath("//div[@class='example'] /div"));
		Actions a = new Actions(driver);
		for (WebElement option : fig) {
			a.moveToElement(option).build().perform();
			option.findElement(By.linkText("View profile")).click();
			String text = driver.findElement(By.tagName("h1")).getText();
			Assert.assertEquals("Not Found", text);
			driver.navigate().back();
		}
	}
		//@Test
		public void infiniteScroll() throws InterruptedException {
			driver.manage().window().maximize();
			driver.get("http://the-internet.herokuapp.com/infinite_scroll");
			Actions a = new Actions(driver);
			int i=0;
			while(i<6) {
			a.scrollByAmount(100, 800).build().perform();
			Thread.sleep(1000);
			i++;
		}
	}
		//@Test
		public void javascriptAlerts() throws InterruptedException {
			driver.manage().window().maximize();
			driver.get("https://the-internet.herokuapp.com/javascript_alerts");
			driver.findElement(By.xpath("//button[@onclick='jsAlert()']")).click();
			driver.switchTo().alert().accept();
			driver.findElement(By.xpath("//button[@onclick='jsConfirm()']")).click();
			driver.switchTo().alert().accept();
			driver.findElement(By.xpath("//button[@onclick='jsPrompt()']")).click();
			driver.switchTo().alert().sendKeys("asdfgh");
			driver.switchTo().alert().accept();
		}
		//@Test
		public void jqueryui() throws InterruptedException {
			driver.manage().window().maximize();
			driver.get("https://the-internet.herokuapp.com/jqueryui/menu");
			WebElement enable = driver.findElement(By.id("ui-id-3"));
			Actions a = new Actions(driver);
			a.moveToElement(enable).build().perform();
			Thread.sleep(1000);
			WebElement download = driver.findElement(By.id("ui-id-4"));
			a.moveToElement(download).build().perform();
			Thread.sleep(1000);
			driver.findElement(By.id("ui-id-5")).click();
			
		}
		//@Test
		public void keypresses() throws InterruptedException {
			driver.manage().window().maximize();
			driver.get("https://the-internet.herokuapp.com/key_presses");
			WebElement keys = driver.findElement(By.cssSelector("#target"));
			Actions a = new Actions(driver);
			a.moveToElement(keys).sendKeys(Keys.CONTROL).build().perform();
			Thread.sleep(1000);
			driver.findElement(By.cssSelector("#result")).getText();
			System.out.println(driver.findElement(By.cssSelector("#result")).getText());
			a.sendKeys(Keys.ALT).build().perform();
			Thread.sleep(1000);
			a.keyDown(Keys.ARROW_DOWN).build().perform();
			Thread.sleep(1000);
			a.keyDown(Keys.SHIFT).sendKeys("a").build().perform();
			System.out.println(driver.findElement(By.cssSelector("#result")).getText());
		}
		//@Test
		public void window() throws InterruptedException {
			driver.manage().window().maximize();
			driver.get("https://the-internet.herokuapp.com/windows");
			driver.findElement(By.xpath("//a[text()='Click Here']")).click();
			Set<String> handle = driver.getWindowHandles();
			Iterator<String> it = handle.iterator();
			String parentwindow = it.next();
			String childwindow = it.next();
			driver.switchTo().window(childwindow);
			Thread.sleep(1000);
			driver.switchTo().window(parentwindow);
			
		}
		@Test
		public void downloadSecure() throws InterruptedException {
			driver.manage().window().maximize();
			driver.get("https://admin:admin@the-internet.herokuapp.com/download_secure");
			driver.findElement(By.linkText("image-size.ps1")).click();
		}
		
}
