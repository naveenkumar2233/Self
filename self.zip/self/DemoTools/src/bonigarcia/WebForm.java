package bonigarcia;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class WebForm {
	
	WebDriver driver;

	@BeforeTest
	public void beforeEach() {
		driver = new ChromeDriver();
	}

	@AfterTest
	public void tearDown() throws InterruptedException {
		Thread.sleep(Duration.ofSeconds(5).toMillis());
		driver.quit();
	}
	
	@Test
	public void form() throws InterruptedException {
		driver.get("https://bonigarcia.dev/selenium-webdriver-java/web-form.html");
		WebElement dropdown = driver.findElement(By.name("my-select"));
		Select dd = new Select(dropdown);
		dd.selectByIndex(2);
		driver.findElement(By.name("my-datalist")).sendKeys("New York");
		Thread.sleep(1000);
		driver.findElement(By.name("my-date"));

		
	}

}
