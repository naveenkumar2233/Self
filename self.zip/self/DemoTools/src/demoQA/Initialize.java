package demoQA;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Initialize {
	
	public WebDriver driver;

//public Initialize(WebDriver driver) {
//	this.driver = driver;
//}

	public WebDriver initializeDriver() {
		driver = new ChromeDriver();
		driver.get("https://demoqa.com/automation-practice-form");
		return driver;
	}
	
}
