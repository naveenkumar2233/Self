package demoQA;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Practise {
	public WebDriver driver;
	
	@BeforeTest
	public void before() {
		Initialize initialize = new Initialize();
		driver = initialize.initializeDriver();
	}
	
	@Test
	public void test() throws InterruptedException {
		String month = "October";
		String date = "23";
		String year = "1998";
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.findElement(By.id("firstName")).sendKeys("Naveen");
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys("Kumar");
		driver.findElement(By.id("userEmail")).sendKeys("naveen@gmail.com");
		driver.findElement(By.xpath("//label[@for='gender-radio-1']")).click();
		driver.findElement(By.id("userNumber")).sendKeys("456789");
		driver.findElement(By.cssSelector(".react-datepicker-wrapper")).click();
		driver.findElement(By.xpath("//option[text()='"+month+"']")).click();
		//driver.findElement(By.cssSelector("react-datepicker__year-select")).click();
		driver.findElement(By.xpath("//option[text()='"+year+"']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[text()='"+date+"']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//label[@for='hobbies-checkbox-1']")).click();
		driver.findElement(By.xpath("//label[@for='hobbies-checkbox-2']")).click();
		driver.findElement(By.id("currentAddress")).sendKeys("qwertyu asdfg");
		driver.findElement(By.xpath("//div[text()='Select State']")).click();
		List<WebElement> options = driver.findElements(By.cssSelector(".css-1uccc91-singleValue"));
		for(WebElement option: options) {
			if(option.getText().equalsIgnoreCase("Haryana")) {
				option.click();
				break;
			}
		
		}
	}
}
