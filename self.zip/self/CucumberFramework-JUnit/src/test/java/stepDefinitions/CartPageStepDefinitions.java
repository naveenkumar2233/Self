package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.CheckoutPage;
import utils.TextContextSetup;

public class CartPageStepDefinitions {

	public WebDriver driver;	
	String checkoutPageProductName;
	TextContextSetup textContextSetup;
	CheckoutPage checkoutPage;

	public CartPageStepDefinitions(TextContextSetup textContextSetup) {
		this.textContextSetup = textContextSetup;
	    checkoutPage = textContextSetup.pageObjectManager.checkoutPage();
	}
	
	
	@When("^user adds (.+) items and selected product to cart$")
	public void user_adds_items_and_selected_product_to_cart(int num) {
	    checkoutPage.itemQuantity(num);
	    checkoutPage.addItemToCart();
	}
	@Then("proceeds to checkout and validates product name in checkout page")
	public void proceeds_to_checkout_and_validates_product_name_in_checkout_page() throws InterruptedException {
	    checkoutPage.checkoutpages();
	    Thread.sleep(2000);
	    checkoutPageProductName = checkoutPage.getProductName().split("-")[0].trim();
	    Assert.assertEquals(textContextSetup.landingPageProductName, checkoutPageProductName);

	}
	@Then("verify user has ability to enter promocode and place order")
	public void verify_user_has_ability_to_enter_promocode_and_place_order() {
	    Assert.assertTrue(checkoutPage.verifyPromo());
	    Assert.assertTrue(checkoutPage.verifyPlaceOrder());
	}
}
