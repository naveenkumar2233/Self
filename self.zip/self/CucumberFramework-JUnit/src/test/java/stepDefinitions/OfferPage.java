package stepDefinitions;

import java.util.Iterator;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.LandingsPage;
import pageObjects.OffersPage;
import utils.TextContextSetup;

public class OfferPage {

public WebDriver driver;	
public String offerPageProductName;
public String landingPageProductName;
TextContextSetup textContextSetup;

public OfferPage(TextContextSetup textContextSetup) {
	this.textContextSetup = textContextSetup;
}


	@Then("^user searched for same (.+) shortname in offers page$")
	public void user_searched_for_same_shortname_in_offers(String shortName) throws InterruptedException {
		
		switchToOffersPage();		
		OffersPage offersPage = textContextSetup.pageObjectManager.getOfferPage();
		offersPage.searchItem(shortName);
		Thread.sleep(2000);
	    offerPageProductName = offersPage.getProductName();
	}
	public void switchToOffersPage() {
		LandingsPage landingsPage = textContextSetup.pageObjectManager.getLandingPage();
		landingsPage.topDealsPage();
		textContextSetup.genericUtils.switchToChildWindow();
	}
	
	@Then("validate product name in offers page matches with landing page")
	public void validate_product_name_in_offers_page_matches_with_landing_page() {
	    Assert.assertEquals(textContextSetup.landingPageProductName, offerPageProductName);
	}
	
}
