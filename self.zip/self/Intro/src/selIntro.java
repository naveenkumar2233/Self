import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class selIntro {

	public static void main(String[] args) {
		
		
	//Invoking Driver
		
		
//	chromeDriver.exe -> chrome browser
	System.setProperty("WebDriver.chrome.driver", "C:/Users/navebodd/Documents/chromedriver.exe");
	WebDriver driver = new ChromeDriver();
//	
	//webdriver.chrome.driver -> value of path
	
	
	//Fiefox launch
	//geckodriver
	//WebDriver.gecko.driver
		
//	System.setProperty("WebDriver.gecko.driver", "C:/Users/navebodd/Documents/geckodriver.exe");
//	WebDriver driver = new FirefoxDriver();


	//Microsoft edge
	//WebDriver.edge.driver
		
//	System.setProperty("WebDriver.edge.driver", "C:/Users/navebodd/Documents/msedgedriver.exe");
//	WebDriver driver = new EdgeDriver();
	
	driver.get("https://rahulshettyacademy.com/");
	
	
	
	System.out.println(driver.getTitle());
	System.out.println(driver.getCurrentUrl());
	driver.close();
	driver.quit();
	
	
	
	
	

	}

}
