package StreamTutorials;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Test1 {

	public static void main(String[] args) {
	
		// TODO Auto-generated method stub

		ArrayList<String> names = new ArrayList<String>();
		names.add("Abhijeet");
		names.add("Ram");
		names.add("Naveen");
		names.add("Adam");
		int count = 0;
		/*for(int i=0;i<names.size();i++) {
			String name = names.get(i);
			if(name.startsWith("A")) {
				count++;
			}
			
		}*/
		
		Long c = names.stream().filter(s-> s.startsWith("A")).count();
		System.out.println(c);
		
		Long d = Stream.of("Abhijeet","Don","Adam","Rama","Alekhya").filter(s-> {
			s.endsWith("A");
			return true;
		}).count();
		System.out.println(d);
		System.out.println("--------------------");
		names.stream().filter(s->s.length()>4).limit(2).forEach(s->System.out.println(s));
		
		System.out.println("--------------------");
		System.out.println("--------------------");
		//StreamMap
		//print names which have last letter as a with uppecase
		Stream.of("Abhijeet","Don","Adam","Rama","Alekhya").filter(s->s.endsWith("a")).map(s->s.toUpperCase())
		.forEach(s->System.out.println(s));
		System.out.println("--------------------");
		System.out.println("--------------------");
		//print names which have first letter as a with uppercase in sorted way
		List<String> names1 = Arrays.asList("Altran","Don","Adam","Rama","Alekhyas","Alekhya");
		names1.stream().filter(s->s.startsWith("A")).sorted().map(a->a.toUpperCase())
		.forEach(n->System.out.println(n));
		System.out.println("--------------------");
		System.out.println("--------------------");
		//Merging 2 diff lists
		Stream<String> newStream = Stream.concat(names.stream(), names1.stream());
		//newStream.sorted().forEach(s->System.out.println(s));
		boolean flag = newStream.anyMatch(s->s.equalsIgnoreCase("ram")); //cannot access newstream again
		System.out.println(flag);
		Assert.assertTrue(flag);
		
		List<String> li = Stream.of("Abhijeet","Don","Adam","Rama","Alekhya").filter(s->s.startsWith("A")).sorted().map(s->s.toUpperCase()).collect(Collectors.toList());
		System.out.println(li.get(1));
	
		List<Integer> values = Arrays.asList(1,8,5,2,3,8,2,4);
		//values.stream().distinct().sorted().forEach(s->System.out.println(s));
		List<Integer> num= values.stream().distinct().sorted().collect(Collectors.toList());
		System.out.println(num.get(2));
	}

}
