import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Assignment {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		
		System.setProperty("WebDriver.chrome.driver", "C:/Users/navebodd/Documents/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/angularpractice/");
		
		driver.findElement(By.xpath("//div/input[@name='name']")).sendKeys("Naveen");
		driver.findElement(By.cssSelector("input[name='email']")).sendKeys("naveen@gmail.com");
		driver.findElement(By.cssSelector("input[placeholder='Password']")).sendKeys("123456");
		driver.findElement(By.id("exampleCheck1")).click();
		WebElement StaticDropdown = driver.findElement(By.id("exampleFormControlSelect1"));
		Select gender = new Select(StaticDropdown);
		gender.selectByVisibleText("Male");
		System.out.println(gender.getFirstSelectedOption().getText());
		
		driver.findElement(By.id("inlineRadio1")).click();
		driver.findElement(By.cssSelector("input[name='bday']")).sendKeys("23-10-1999");
		driver.findElement(By.cssSelector(".btn-success")).click();
		Thread.sleep(2000);
		System.out.println(driver.findElement(By.cssSelector(".alert")).getText());
		
	}

}
