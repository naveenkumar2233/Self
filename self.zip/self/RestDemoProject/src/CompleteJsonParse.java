import files.Payload;
import io.restassured.path.json.JsonPath;

public class CompleteJsonParse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		JsonPath js = new JsonPath(Payload.coursePrice());
		
		int count = js.getInt("courses.size()");
		System.out.println(count);
		
		int purchaseAmount = js.getInt("dashboard.purchaseAmount");
		System.out.println(purchaseAmount);
		
		String firstTitle = js.get("courses[0].title");
		System.out.println(firstTitle);
		
		
		
		for(int i=0;i<count;i++) {
			String courseTitles = js.get("courses["+i+"].title");
			System.out.println(courseTitles);
			System.out.println(js.getString("courses["+i+"].price").toString());
			
		}
		
		for(int i=0;i<count;i++) {
			
			String courseTitles = js.get("courses["+i+"].title");
			if(courseTitles.equalsIgnoreCase("RPA")) {
				int copies = js.get("courses["+i+"].copies");
				System.out.println(copies);
				break;
			}
		
	}
	}
}


