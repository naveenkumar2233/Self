package Ecommerce;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import static io.restassured.RestAssured.*;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;

import Pojo.LoginRequest;
import Pojo.LoginResponse;
import Pojo.OrderDetails;
import Pojo.Orders;

public class ECommerceAPITest {

	public static void main(String[] args) {
		
		LoginRequest login = new LoginRequest();
		login.setUserEmail("naveenkumarb@gmail.com");
		login.setUserPassword("N@veen141");
		
		RequestSpecification req = new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com")
		.setContentType(ContentType.JSON).build();
		
		
		RequestSpecification reqspec = given().log().all().spec(req).body(login);
		LoginResponse loginResponse = reqspec.when().post("/api/ecom/auth/login").then().log().all()
				.extract().response().as(LoginResponse.class);
		System.out.println(loginResponse.getToken());
		String token = loginResponse.getToken();
		System.out.println(loginResponse.getUserId());
		String userId = loginResponse.getUserId();
		
		//AddProduct
		
		RequestSpecification addProductBaseReq = new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com")
				.addHeader("Authorization",token).build();
		
		RequestSpecification addProduct = given().log().all().spec(addProductBaseReq).formParam("productName","laptop").formParam("productAddedBy",userId)
		.formParam("productCategory","electronics").formParam("productSubCategory","laptops")
		.formParam("productPrice","11500").formParam("productDescription","Lenova")
		.formParam("productFor","all")
		.multiPart("productImage", new File("C:\\Users\\navebodd\\Pictures\\Screenshots\\product.png"));
		
		String addProductResponse = addProduct.when().post("/api/ecom/product/add-product")
		.then().log().all().assertThat().statusCode(201).extract().response().asString();
		JsonPath js = new JsonPath(addProductResponse);
		String productId = js.get("productId");
		
		//Create Order
		
		
		RequestSpecification createOderBaseReq = new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com")
				.addHeader("Authorization", token).setContentType(ContentType.JSON).build();
		
		OrderDetails orderDetails = new OrderDetails();
		orderDetails.setCountry("India");
		orderDetails.setProductOrderedId(productId);
		
		List<OrderDetails> orderDetailsList = new ArrayList<OrderDetails>();
		orderDetailsList.add(orderDetails);
		
		Orders order = new Orders();
		order.setOrders(orderDetailsList);
		
		RequestSpecification createOderReq = given().log().all().spec(createOderBaseReq).body(order);
		String responseAddOrder = createOderReq.when().post("/api/ecom/order/create-order")
		.then().log().all().extract().response().asString();
		JsonPath js1 = new JsonPath(responseAddOrder);
		 List<Object> orders = js1.getList("orders");
		 System.out.println(orders);
		
		//View Order Details
		
		RequestSpecification viewOrderBaseReq = new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com")
				.addHeader("Authorization", token).build();
		
		RequestSpecification viewOrderReq = given().spec(viewOrderBaseReq).queryParam("id",orders);
		
		String viewOrderResponse = viewOrderReq
				.when().get("/api/ecom/order/get-orders-details")
		.then().log().all().extract().response().asString();
		System.out.println(viewOrderResponse);
		
		//DeleteOrder
		RequestSpecification deleteOrderBaseReq = new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com")
				.addHeader("Authorization", token).build();
		RequestSpecification deleteOrderReq = given().log().all().spec(deleteOrderBaseReq)
				.pathParam("productId", productId);
		
		String deleteResponse = deleteOrderReq.when().delete("/api/ecom/product/delete-product/{productId}")
		.then().log().all().extract().response().asString();
		JsonPath js2 = new JsonPath(deleteResponse);
		String message = js2.get("message");
		Assert.assertEquals("Product Deleted Successfully", message);
		
	}

}
