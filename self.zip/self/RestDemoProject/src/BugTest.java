import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

import java.io.File;

public class BugTest {

	
	public static void main(String[] args) {
		
		RestAssured.baseURI="https://naveenkumar141.atlassian.net/";
		
		String createIssueResponse = given().header("Content-Type","application/json")
		.header("Authorization","Basic bmF2ZWVuLmJpdHR1MTQxQGdtYWlsLmNvbTpBVEFUVDN4RmZHRjB0M19pLXM1ZkhOY2U5dmpZT0hHenRiamxSWkMzVVdENjVtTWg2WG1COGI1MW83c2pBM3pkS1lLS1VnZW1wOHFyVGNnT1ZjTkdqazBQd0J0YUV2bFZRRDgtTS1kSTZmaFdGbTlsMGFlUmhWcHFaQl9HZE04SkkyQzRvNjVnSHpLcHYyaHRqSFFoQmlPMGNsN2pZb0QyREQ3OFNBZXczUjJxUTEtLTJNOVZzakU9RTEwQTZBQzk=")
		.body("{\r\n"
				+ "    \"fields\": {\r\n"
				+ "       \"project\":\r\n"
				+ "       {\r\n"
				+ "          \"key\": \"SCRUM\"\r\n"
				+ "       },\r\n"
				+ "       \"summary\": \"WebSite is not working:Automation\",\r\n"
				+ "       \"issuetype\": {\r\n"
				+ "          \"name\": \"Bug\"\r\n"
				+ "       }\r\n"
				+ "   }\r\n"
				+ "}").log().all()
		.when().post("/rest/api/3/issue")
		.then().log().all().assertThat().statusCode(201).extract().response().asString();
		JsonPath js = new JsonPath(createIssueResponse);
		String issueid = js.get("id");
		System.out.println(issueid);
		
		given()
		.pathParam("key", issueid)
		.header("X-Atlassian-Token","no-check")
		.header("Authorization","Basic bmF2ZWVuLmJpdHR1MTQxQGdtYWlsLmNvbTpBVEFUVDN4RmZHRjBOc0djbmZVRDRzbzZPS0RUdm02WUVyZU1xa0RqRERnU1BIVEM5S055TmFLNzVqbnhrOXBtaVVIbXh6Z3FXTWRITVZsUlI0Q01SUm1CTDdWXy13THJ5enlsUmY1cVpRSTJHbTFjVzJULWxCcDlvcmdpaXpLbzB2ZXdoLU16bjlhMFRVN0FsR2JNYXcwTjgwb1puSHlFMlJNcmxZQ2lpQTRaZWE5YWYwRV82SkU9MTQyNDc0NEY=")
		.multiPart("file",new File("C:\\Users\\navebodd\\Pictures\\Screenshots\\Screenshot (1).png"))
		.log().all()
		.when().post("/rest/api/3/issue/{key}/attachments")
		.then().log().all().assertThat().statusCode(200);
		
	}
}
