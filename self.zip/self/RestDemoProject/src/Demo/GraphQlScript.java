package Demo;

import static io.restassured.RestAssured.*;

import org.testng.Assert;

import files.Payload;
import files.ReUsableMethods;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class GraphQlScript {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Query
		int characterId = 13432,episodeId = 13650;
		RestAssured.baseURI = "https://rahulshettyacademy.com/";
		String response = given().log().all().header("content-type","application/json")
		.body(Payload.addQuery(characterId,episodeId))
		.when().post("/gq/graphql")
		.then().log().all().extract().response().asString();
		JsonPath js = ReUsableMethods.rawTOJson(response);
		String episodeName = js.get("data.episode.name");
		Assert.assertEquals(episodeName, "Battle of Bastards");
		
		//Mutations
		String newCharacter = "AryaStark";
		String mutationResponse = given().log().all().header("content-type","application/json")
				.body(Payload.addMutation(newCharacter))
				.when().post("/gq/graphql")
				.then().log().all().extract().response().asString();
				JsonPath js1 = ReUsableMethods.rawTOJson(mutationResponse);
				int locationId = js1.getInt("data.createLocation.id");
				System.out.println(locationId);
	}

}
