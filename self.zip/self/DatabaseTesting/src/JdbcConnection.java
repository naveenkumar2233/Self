import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcConnection {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub

		String host = "localhost";
		String port = "3306";

		Connection con = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/demo", "root", "1234");
		Statement s = con.createStatement();
		ResultSet rs = s.executeQuery("select * from credentials where scenario='zerobalancecard'");
		while (rs.next()) {
			rs.getString("username");
			rs.getString("password");
		}

	}

}
